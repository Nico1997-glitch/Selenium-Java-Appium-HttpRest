export const colors = {
  white: '#FFFFFF',
  slRed: '#E2231A',
  superLightGray: 'rgba(237,237,239,0.6)',
  lightGray: '#EDEDEF',
  gray: '#474C55',
};
