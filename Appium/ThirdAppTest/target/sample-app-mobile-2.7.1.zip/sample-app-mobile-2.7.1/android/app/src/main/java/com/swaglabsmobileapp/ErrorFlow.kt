package com.swaglabsmobileapp

annotation class ErrorFlow
